from django.shortcuts import render, redirect
from .models import *
from datetime import date, datetime
from django.contrib import messages
import bcrypt

# Create your views here.
def main(request):
    return render(request, 'login_app/main.html')

def register(request):
    if request.method == 'GET':
        return redirect('/')
    else:
        if request.method == 'POST':
            errors = User.objects.fields_validator(request.POST)

            if len(errors) > 0:
                for key, value in errors.items():
                    messages.error(request,value)

                request.session['registro_name'] = request.POST['name']
                request.session['registro_username'] = request.POST['username']

            else:
                request.session['registro_name'] = ""
                request.session['registro_username'] = ""

                name = request.POST['name']
                username = request.POST['username']
                password_hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
                dh = datetime.strptime(request.POST['datehired'],'%Y-%m-%d').date()

                obj = User.objects.create(name=name, username=username, password=password_hash, date_hired=dh)
                obj.save()
                messages.success(request, "Usuario registrado con éxito")
            
            return redirect('/')

        return render(request, 'login_app/main.html')

def login(request):
    if request.method == 'GET':
        return redirect("/")
    else:
        if request.method == 'POST': 
            user = User.objects.filter(username=request.POST['username']) 
            if len(user) > 0 : 
                usuario_registrado = user[0]
                if bcrypt.checkpw(request.POST['password_login'].encode(), usuario_registrado.password.encode()): 
                    usuario = {
                        'id':usuario_registrado.id,
                        'name':usuario_registrado.name,
                        'username':usuario_registrado.username,
                    }

                    request.session['usuario'] = usuario
                    messages.success(request,"Ingreso correctamente")
                    return redirect('/dashboard')
                else:
                    messages.error(request,"Datos erróneos o el usuario no existe")
                    return redirect('/')
            else:
                messages.error(request,"Datos mal ingresados o el usuario no existe!!!")
                return redirect('/')

