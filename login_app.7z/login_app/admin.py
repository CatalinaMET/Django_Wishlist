from django.contrib import admin
from login_app.models import *

# Register your models here.
admin.site.register(User)

