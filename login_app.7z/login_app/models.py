from django.db import models
from datetime import date, datetime
import re

# Create your models here.
class UserManager(models.Manager):
    def fields_validator(self, postData):
        JUST_LETTERS = re.compile(r'^[a-zA-Z.]+$')
        PASSWORD_REGEX = re.compile(r'^(?=\w*[a-zA-Z.])\S{8,15}$')
        #PASSWORD_REGEX = re.compile(r'^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,15}$')
        errors = {}

        if len(User.objects.filter(username=postData['username'])) > 0:
            errors['username_exits'] = "Username exits"
        else:
            if len(postData['name'].strip()) < 3:
                errors['nombre_len'] = "Nombre debe tener al menos 3 caracteres"

            if len(postData['username'].strip()) < 3:
                errors['username_len'] = "Username debe tener al menos 3 caracteres"

            if len(postData['password'].strip()) > 8:
                errors['password_len'] = "Password debe tener al menos 8 caracteres"
                
            if not JUST_LETTERS.match(postData['username']):
                errors['just_letters'] = "Solo se permite el ingreso de letras en el username"
                
            if not PASSWORD_REGEX.match(postData['password']):
                errors['password_format'] = "Formato contraseña no válido" 

            if postData['password'] != postData['password_confirm']:
                errors['password_confirm'] = "Contraseñas no coinciden"
            
            fecha_actual = date.today()
            dh = datetime.strptime(postData['datehired'],'%Y-%m-%d').date()

            diferencia_fecha = fecha_actual - dh
            diferencia_dias = diferencia_fecha.days

            if diferencia_dias < 0:
                errors['dias'] = "Debes ingresar una fecha hoy o anterior para registrate"


        return errors


class User(models.Model):
    name = models.CharField(max_length=50, null=False, blank=False)
    username = models.CharField(max_length=50, unique=True, null=False, blank=False)
    password = models.CharField(max_length=250)
    date_hired = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

    class Meta:
        verbose_name = "usuario"
        verbose_name_plural = "usuarios"
        ordering = ["username",]

    def __str__(self):
            return self.username  


    
        

